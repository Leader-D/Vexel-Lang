import React, { useState, useEffect, useCallback } from 'react';
import { Member, Position, Attendance, Note, Club } from './types';
import Header from './components/Header';
import MemberList from './components/MemberList';
import MemberProfile from './components/MemberProfile';
import AddMemberModal from './components/AddMemberModal';

// For demonstration purposes, we assume the user is an Admin.
// In a real app, this would come from a login system.
const CURRENT_USER_ROLE = Position.ADMIN;

const App: React.FC = () => {
  const [members, setMembers] = useState<Member[]>([]);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    try {
      const storedMembers = localStorage.getItem('members');
      if (storedMembers) {
        // Data migration for existing members without a club
        const parsedMembers: Member[] = JSON.parse(storedMembers).map((member: any) => ({
          ...member,
          club: member.club || Club.NONE // Add default club if not present
        }));
        setMembers(parsedMembers);
      }
    } catch (error) {
      console.error("Failed to load members from local storage", error);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('members', JSON.stringify(members));
    } catch (error) {
      console.error("Failed to save members to local storage", error);
    }
  }, [members]);

  const generateFridays = (): Attendance[] => {
    const fridays: Attendance[] = [];
    const today = new Date();
    // Season is from October of the previous year to June of the current year
    const seasonStartYear = today.getMonth() < 6 ? today.getFullYear() - 1 : today.getFullYear();
    
    let startDate = new Date(seasonStartYear, 9, 1); // Start from October 1st
    const endDate = new Date(seasonStartYear + 1, 5, 30); // End on June 30th

    let currentDate = new Date(startDate);
     while (currentDate.getDay() !== 5) {
        currentDate.setDate(currentDate.getDate() + 1);
    }

    while (currentDate <= endDate) {
      fridays.push({ date: currentDate.toISOString(), present: false });
      currentDate.setDate(currentDate.getDate() + 7);
    }
    return fridays;
  };

  const handleAddMember = (data: Omit<Member, 'id' | 'joinDate' | 'attendance' | 'specialEvents' | 'notes'>) => {
    const newMember: Member = {
      ...data,
      id: crypto.randomUUID(),
      joinDate: new Date().toISOString(),
      attendance: generateFridays(),
      specialEvents: [],
      notes: [],
    };
    setMembers(prev => [...prev, newMember]);
    setIsModalOpen(false);
  };

  const handleDeleteMember = (id: string) => {
    if (window.confirm('هل أنت متأكد من أنك تريد حذف هذا العضو؟')) {
      setMembers(prev => prev.filter(member => member.id !== id));
      if (selectedMember?.id === id) {
        setSelectedMember(null);
      }
    }
  };

  const handleSelectMember = (member: Member) => {
    setSelectedMember(member);
  };

  const handleBackToList = () => {
    setSelectedMember(null);
  };

  const handleUpdateMember = useCallback((updatedMember: Member) => {
    setMembers(prev => prev.map(m => m.id === updatedMember.id ? updatedMember : m));
    setSelectedMember(updatedMember);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <Header onAddMemberClick={() => setIsModalOpen(true)} showAddButton={!selectedMember} />
      <main className="container mx-auto p-4 md:p-8">
        {selectedMember ? (
          <MemberProfile 
            member={selectedMember} 
            onBack={handleBackToList} 
            onUpdate={handleUpdateMember}
            onDelete={handleDeleteMember}
            currentUserRole={CURRENT_USER_ROLE}
          />
        ) : (
          <MemberList 
            members={members} 
            onSelectMember={handleSelectMember} 
            onDeleteMember={handleDeleteMember} 
          />
        )}
      </main>
      <AddMemberModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAddMember={handleAddMember}
      />
    </div>
  );
};

export default App;
