import React, { useState } from 'react';
import { Position, Member, Club } from '../types';

interface AddMemberModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddMember: (data: Omit<Member, 'id' | 'joinDate' | 'attendance' | 'specialEvents' | 'notes'>) => void;
}

const AddMemberModal: React.FC<AddMemberModalProps> = ({ isOpen, onClose, onAddMember }) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [age, setAge] = useState('');
  const [enrollmentYear, setEnrollmentYear] = useState('');
  const [phone1, setPhone1] = useState('');
  const [phone2, setPhone2] = useState('');
  const [position, setPosition] = useState<Position>(Position.FTY);
  const [club, setClub] = useState<Club>(Club.NONE);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (firstName.trim() && lastName.trim() && age && enrollmentYear && phone1) {
      onAddMember({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        age: parseInt(age),
        enrollmentYear: parseInt(enrollmentYear),
        phone1,
        phone2,
        position,
        club,
      });
      // Reset form
      setFirstName('');
      setLastName('');
      setAge('');
      setEnrollmentYear('');
      setPhone1('');
      setPhone2('');
      setPosition(Position.FTY);
      setClub(Club.NONE);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-lg shadow-2xl p-6 md:p-8 w-full max-w-lg transform transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-2xl font-bold mb-6 text-gray-800">إضافة عضو جديد</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">الاسم</label>
              <input type="text" id="firstName" value={firstName} onChange={(e) => setFirstName(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" required />
            </div>
            <div>
              <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">اللقب</label>
              <input type="text" id="lastName" value={lastName} onChange={(e) => setLastName(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" required />
            </div>
            <div>
              <label htmlFor="age" className="block text-sm font-medium text-gray-700 mb-1">العمر</label>
              <input type="number" id="age" value={age} onChange={(e) => setAge(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" required />
            </div>
            <div>
              <label htmlFor="enrollmentYear" className="block text-sm font-medium text-gray-700 mb-1">سنة الانخراط</label>
              <input type="number" id="enrollmentYear" value={enrollmentYear} onChange={(e) => setEnrollmentYear(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" required />
            </div>
             <div>
              <label htmlFor="phone1" className="block text-sm font-medium text-gray-700 mb-1">رقم الهاتف الأول</label>
              <input type="tel" id="phone1" value={phone1} onChange={(e) => setPhone1(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" required />
            </div>
             <div>
              <label htmlFor="phone2" className="block text-sm font-medium text-gray-700 mb-1">رقم الهاتف الثاني <span className="text-gray-400">(اختياري)</span></label>
              <input type="tel" id="phone2" value={phone2} onChange={(e) => setPhone2(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="position" className="block text-sm font-medium text-gray-700 mb-1">المنصب</label>
              <select id="position" value={position} onChange={(e) => setPosition(e.target.value as Position)} className="w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                {Object.values(Position).map((pos) => (
                  <option key={pos} value={pos}>{pos}</option>
                ))}
              </select>
            </div>
             <div>
              <label htmlFor="club" className="block text-sm font-medium text-gray-700 mb-1">النادي</label>
              <select id="club" value={club} onChange={(e) => setClub(e.target.value as Club)} className="w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                {Object.values(Club).map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-4 pt-4">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors">إلغاء</button>
            <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">إضافة العضو</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddMemberModal;
