import React from 'react';
import { Member } from '../types';
import TrashIcon from './icons/TrashIcon';
import UserIcon from './icons/UserIcon';

interface MemberListProps {
  members: Member[];
  onSelectMember: (member: Member) => void;
  onDeleteMember: (id: string) => void;
}

const MemberList: React.FC<MemberListProps> = ({ members, onSelectMember, onDeleteMember }) => {
  if (members.length === 0) {
    return (
      <div className="text-center py-16">
        <UserIcon className="mx-auto h-24 w-24 text-gray-400" />
        <h2 className="mt-4 text-2xl font-semibold text-gray-600">لا يوجد أعضاء بعد</h2>
        <p className="mt-2 text-gray-500">ابدأ بإضافة عضو جديد لعرضه في القائمة.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                الاسم الكامل
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                المنصب
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                تاريخ الانضمام
              </th>
              <th scope="col" className="relative px-6 py-3">
                <span className="sr-only">إجراءات</span>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {members.map((member) => (
              <tr key={member.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">{member.firstName} {member.lastName}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    {member.position}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {new Date(member.joinDate).toLocaleDateString('ar-EG')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-left text-sm font-medium">
                  <div className="flex items-center justify-end gap-x-4">
                    <button
                      onClick={() => onSelectMember(member)}
                      className="text-blue-600 hover:text-blue-900 transition-colors"
                      title="عرض الملف الشخصي"
                    >
                      عرض الملف الشخصي
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteMember(member.id);
                      }}
                      className="text-red-600 hover:text-red-900 transition-colors"
                      title="حذف العضو"
                    >
                      <TrashIcon />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MemberList;