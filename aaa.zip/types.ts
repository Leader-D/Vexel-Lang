export enum Club {
  IT = 'نادي الإعلام الآلي',
  READING = 'نادي القراءة',
  SPORTS = 'نادي الرياضة',
  ARTS = 'نادي الفنون',
  NONE = 'بدون نادي',
}

export enum Position {
  FTY = 'فتى',
  ASSISTANT = 'مساعد مؤطر',
  LEADER = 'مؤطر',
  ADMIN = 'مسؤول',
}

export interface Attendance {
  date: string; // Storing date as ISO string
  present: boolean;
}

export interface SpecialEventAttendance {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  attendance: Attendance[];
}

export interface Note {
  id: string;
  content: string;
  date: string;
}

export interface Member {
  id: string;
  firstName: string;
  lastName: string;
  age: number;
  enrollmentYear: number;
  phone1: string;
  phone2?: string;
  position: Position;
  club: Club;
  joinDate: string; // Storing date as ISO string
  attendance: Attendance[];
  specialEvents: SpecialEventAttendance[];
  notes: Note[];
}
